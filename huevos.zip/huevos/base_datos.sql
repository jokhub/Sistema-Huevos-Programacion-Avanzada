CREATE DATABASE eggceptional;

\c eggceptional;

CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nombre_usuario VARCHAR(50) UNIQUE NOT NULL,
    contrasena VARCHAR(50) NOT NULL,
    rol VARCHAR(20) NOT NULL CHECK (rol IN ('gerente', 'administrador'))
);

create table clientes (
    id SERIAL PRIMARY key,
    nombre VARCHAR(30) not NULL,
    telefono VARCHAR(8)
    nit VARCHAR(15)
    estado VARCHAR(50)
)

create table venta (
    id SERIAL PRIMARY key,
    id_usuario,
    id_cliente,
    fecha date,
    total float
)

create table reporte (
    id serial PRIMARY key,
    tipo varchar(20),
    fecha_gen date,
    descripcion varchar(1000),
    id_usuario
)

CREATE table detalle_venta (
    id_detalle serial PRIMARY key,
    id_venta,
    id_producto,
    cantidad float,
    precio float,
)

create table producto (
    id_producto serial PRIMARY key,
    nombre varchar(100),
    tipo varchar(30),
    precio_unitario float,
    precio_mayor float
)

create table inventario (
    id serial PRIMARY key,
    id_producto,
    cantidad float,
    fecha_actualizacion date
)

INSERT INTO usuarios (nombre_usuario, contrasena, rol) VALUES
('gerente1', '1234', 'gerente'),
('admin1', 'abcd', 'administrador');

